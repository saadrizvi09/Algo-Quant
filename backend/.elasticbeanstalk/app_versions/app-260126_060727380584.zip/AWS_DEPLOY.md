# AWS Elastic Beanstalk Deployment Guide

## Quick Deploy Steps

1. Install AWS CLI and EB CLI
2. Configure AWS credentials
3. Initialize EB application
4. Deploy
5. Update frontend to use AWS backend URL

## Environment Variables to Set in AWS
- SECRET_KEY=your-secret-key
- FRONTEND_URL=https://your-vercel-app.vercel.app

## Backend URL
After deployment, you'll get a URL like:
http://algoquant-env.eba-xxxxx.us-east-1.elasticbeanstalk.com
